#!/bin/sh
exec /opt/caskade-fixture/FixtureGame.x86_64 "$@"
